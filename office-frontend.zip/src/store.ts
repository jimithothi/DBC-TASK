import { configureStore } from '@reduxjs/toolkit';
import leaderBoardSlice from './leaderBoardSlice';

export const store = configureStore({
  reducer: {
    leaderBoard: leaderBoardSlice.reducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

