import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from './axiosInstance';

// Define a proper user type if available
export interface User {
  _id: string;
  username: string;
  totalPoints: number;
}

interface LeaderBoardState {
  users: User[];
  loading: boolean;
  error: string | null;
}

const initialState: LeaderBoardState = {
  users: [],
  loading: false,
  error: null,
};

export const leaderBoardUsers = createAsyncThunk(
  'leaderBoardUsers',
  async () => {
    try {
      const response = await axiosInstance.get('/api/leaderboard/user');
      return response.data;
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    } catch (err: unknown) {
      return [];
    }
  }
);

export const recalculate = createAsyncThunk(
  'recalculate',
  async () => {
    try {
      const response = await axiosInstance.post('/api/leaderboard/re-calculate',{});
      return response.data;
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    } catch (err: unknown) {
      return [];
    }
  }
);

const leaderBoardSlice = createSlice({
  name: 'leaderBoard',
  initialState,
  reducers: {}, // Add this line
  extraReducers: (builder) => {
    builder
      .addCase(leaderBoardUsers.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(leaderBoardUsers.fulfilled, (state, action) => {
        state.loading = false;
        state.users = action.payload; 
      })
      .addCase(leaderBoardUsers.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(recalculate.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(recalculate.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(recalculate.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default leaderBoardSlice; 