import './App.css'
import { Routes, Route } from 'react-router-dom';
import LeaderBoard from './LeaderBoard';

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<LeaderBoard />} />        
      </Routes>
    </>
  );
}

export default App;
