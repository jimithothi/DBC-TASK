import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { leaderBoardUsers, recalculate, type User } from './leaderBoardSlice';
import type { RootState, AppDispatch } from './store'; // adjust path as needed

const LeaderBoard: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>(); // ✅ typed dispatch
  const [searchTerm, setSearchTerm] = useState('');

  const { users, loading, error } = useSelector((state: RootState) => state.leaderBoard);

  useEffect(() => {
    dispatch(leaderBoardUsers());
  }, [dispatch]);

  const filteredUsers = [...users]
    .sort((a, b) => b.totalPoints - a.totalPoints) // 1. Sort by points
    .sort((a, b) => {
      // 2. Exact match boost to top
      if (searchTerm && a.username.toLowerCase() === searchTerm.toLowerCase()) return -1;
      if (searchTerm && b.username.toLowerCase() === searchTerm.toLowerCase()) return 1;
      return 0;
    });

    
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleRecalculate = async () => {
    try {
      await dispatch(recalculate()).unwrap();
      dispatch(leaderBoardUsers());
    } catch (error) {
      console.error('Error recalculating:', error);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;
  if (users.length === 0) return <div>No users found.</div>;

  return (
    <>
      <div style={{ marginBottom: '1rem' }}>
        <button onClick={handleRecalculate}>Recalculate</button>
        <input
          type="text"
          placeholder="Search username..."
          value={searchTerm}
          onChange={handleSearchChange}
          style={{ marginLeft: '1rem', padding: '4px' }}
        />
      </div>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Username</th>
            <th>Total Points</th>
          </tr>
        </thead>
        <tbody>
          {filteredUsers.map((user: User, index: number) => (
            <tr key={user._id}>
              <td>{index + 1}</td>
              <td>{user.username}</td>
              <td>{user.totalPoints}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
};

export default LeaderBoard;
