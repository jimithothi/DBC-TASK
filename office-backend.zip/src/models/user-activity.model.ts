import mongoose from 'mongoose';

const userActivitySchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  activityName: {type: String, required: true},
  occurrenceDate: { type: Date },
}, {
  timestamps: true
});

userActivitySchema.index({ user: 1, activity: 1, occurrenceDate: 1 }, { unique: true });

const UserActivity = mongoose.model('UserActivity', userActivitySchema);

export default UserActivity;
