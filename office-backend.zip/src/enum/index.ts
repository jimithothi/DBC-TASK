export enum FilterType {
            YEAR = "year",
            MONTH = "month",
            DATE = "date"
        }