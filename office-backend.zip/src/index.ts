import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import rateLimit from 'express-rate-limit';
import leaderBoardRoutes from './routes/leader-board.routes';
import { errorHandler } from './middleware/error.middleware';

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use(limiter);


// Error handling
app.use(errorHandler);
app.use('/api/leaderboard', leaderBoardRoutes);
const MONGODB_URI = process.env.DB_URL || "mongodb://localhost:27017/leader-board";

// Database connection
mongoose.connect(MONGODB_URI, {
  serverSelectionTimeoutMS: 30000 // 30 seconds
})
  .then(() => console.log('Connected to MongoDB'))
  .catch((error) => console.error('MongoDB connection error:', error));

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
}); 
