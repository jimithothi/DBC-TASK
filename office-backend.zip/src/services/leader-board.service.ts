import UserActivity from "../models/user-activity.model";
import { FilterType } from "../enum";
import User from "../models/user.model";

export class LeaderBoardService {
  static async leaderboard(date: string, type: string): Promise<any> {
    const result = await User.aggregate([
      {
        $lookup: {
          from: 'useractivities',
          let: { userId: '$_id' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $eq: ['$user', '$$userId']
                }
              }
            },
            ...(type && date
              ? [
                  {
                    $addFields: {
                      year: { $year: '$occurrenceDate' },
                      month: { $month: '$occurrenceDate' },
                      day: { $dayOfMonth: '$occurrenceDate' }
                    }
                  },
                  {
                    $match: (() => {
                      const parsedDate = new Date(date);
                      const year = parsedDate.getFullYear();
                      const month = parsedDate.getMonth() + 1;
                      const day = parsedDate.getDate();
                      if (type === FilterType.YEAR) {
                        return { year };
                      } else if (type === FilterType.MONTH) {
                        return { year, month };
                      } else if (type === FilterType.DATE) {
                        return { year, month, day };
                      } else {
                        return {};
                      }
                    })()
                  }
                ]
              : [])
          ],
          as: 'activities'
        }
      },
      {
        $project: {
          _id: 1,
          username: 1,
          totalPoints: {
            $sum: {
              $map: {
                input: '$activities',
                as: 'activity',
                in: 20 // fixed points, adjust if needed
              }
            }
          }
        }
      },
      {
        $sort: { totalPoints: -1 } // ✅ Sort by totalPoints descending
      } 
    ]);

    return result;
  }

  static getRandomInt(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  static getRandomDateWithinLastDays(days: number): Date {
    const now = new Date();
    const offset = LeaderBoardService.getRandomInt(0, days);
    return new Date(now.getTime() - offset * 24 * 60 * 60 * 1000);
  }

  static async recalculate() {
    try {
      const activityNames = ['Running', 'Swimming', 'Walking', 'Playing', 'Singing', 'Dancing', 'Cycling', 'Hiking'];
      const firstNames = ['John', 'Jane', 'Bob', 'Alice', 'Charlie', 'Eve', 'Tom', 'Sue', 'Alex', 'Sam'];
      const lastNames = ['Doe', 'Smith', 'Johnson', 'Brown', 'Green', 'Taylor', 'Clark'];

      await User.deleteMany({});
      await UserActivity.deleteMany({});

      const users = await User.insertMany(
        Array.from({ length: 10 }).map(() => ({
          username: `${firstNames[LeaderBoardService.getRandomInt(0, firstNames.length - 1)]} ${lastNames[LeaderBoardService.getRandomInt(0, lastNames.length - 1)]}`
        }))
      );

      const activityData = users.flatMap(user => {
        const activityCount = LeaderBoardService.getRandomInt(3, 7);
        return Array.from({ length: activityCount }).map(() => ({
          user: user._id,
          activityName: activityNames[LeaderBoardService.getRandomInt(0, activityNames.length - 1)],
          occurrenceDate: LeaderBoardService.getRandomDateWithinLastDays(30)
        }));
      });

      await UserActivity.insertMany(activityData);
      console.log('Random seeder data inserted successfully!');
    } catch (error) {
      console.error('Error inserting random seeder data:', error);
    }
  }
}
