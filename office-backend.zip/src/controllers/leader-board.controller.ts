import { Request, Response } from 'express';
import { LeaderBoardService } from '../services/leader-board.service';
import seeds from '../seeds';
 
/**
 * This methos used for find leader board users with sorting
 * @param req 
 * @param res 
 */
export const leaderboard = async (req: Request, res: Response) => {
  try {
    const result = await LeaderBoardService.leaderboard( req.query.filterValue as string,req.query.filterType as string);
    res.status(201).json(result);
  } catch (error: any) {
    res.status(error.status || 500).json({ message: error.message || 'Server error', error });
  }
};



/**
 * This method is used to re-calculate the leader board by re-seeding the data
 * @param req Express Request object
 * @param res Express Response object
 */
export const recalculate = async (req: Request, res: Response) => {
  try {
    const result = await LeaderBoardService.recalculate();    
    res.status(200).json({ message: 'Seeding completed successfully!' });
  } catch (error: any) {
    console.error('Seeding failed:', error);
    res.status(500).json({
      message: 'Seeding failed',
      error: error.message || error
    });
  }
};