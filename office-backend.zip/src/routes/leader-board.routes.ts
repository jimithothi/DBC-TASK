import { Router } from 'express';
import { body } from 'express-validator';
import { leaderboard, recalculate } from '../controllers/leader-board.controller';

const router = Router();

 router.get(
   '/user',
   leaderboard
 );

 router.post(
   '/re-calculate',
   recalculate
 );

export default router; 