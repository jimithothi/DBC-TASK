// src/seeds/seed.ts
import mongoose from 'mongoose';
import User from '../models/user.model';
import UserActivity from '../models/user-activity.model';

const seeds = async () => {
  try {
    const MONGODB_URI = process.env.DB_URL || "mongodb://localhost:27017/leader-board";
    mongoose.connect(MONGODB_URI, {
      serverSelectionTimeoutMS: 30000 // 30 seconds
    })
      .then(() => console.log('Connected to MongoDB'))
      .catch((error) => console.error('MongoDB connection error:', error));
    
    // Delete all existing data
    await User.deleteMany({});
    await UserActivity.deleteMany({});

    // Create users
    const users = await User.insertMany([
      { username: 'John Doe' },
      { username: 'Jane Doe' },
      { username: 'Bob Smith' },
      { username: 'Alice Johnson' },
      { username: 'Charlie Brown' },
      { username: 'Eve Green' },
      { username: 'Tom Brown' },
      { username: 'Sue Green' },
      { username: 'Bob Johnson' },
      { username: 'Alice Brown' },
    ]);
    // Create user activities
    await UserActivity.insertMany([
      { user: users[0]._id, activityName: "Running", occurrenceDate: new Date() },
      { user: users[0]._id, activityName: "Swimming", occurrenceDate: new Date() },
      { user: users[0]._id, activityName: "Walking", occurrenceDate: new Date() },
      { user: users[0]._id, activityName: "Playing", occurrenceDate: new Date() },
      { user: users[0]._id, activityName: "Singing", occurrenceDate: new Date() },
      { user: users[0]._id, activityName: "Dancing", occurrenceDate: new Date() },      
      
      { user: users[1]._id, activityName: "Running", occurrenceDate: new Date() },
      { user: users[1]._id, activityName: "Dancing", occurrenceDate: new Date() },
      { user: users[1]._id, activityName: "Singing", occurrenceDate: new Date() },
      { user: users[1]._id, activityName: "Playing", occurrenceDate: new Date() },
      { user: users[1]._id, activityName: "Walking", occurrenceDate: new Date() },
      
      { user: users[2]._id, activityName: "Running", occurrenceDate: new Date() },
      { user: users[2]._id, activityName: "Running", occurrenceDate: new Date() },
      { user: users[2]._id, activityName: "Walking", occurrenceDate: new Date() },
      { user: users[2]._id, activityName: "Dancing", occurrenceDate: new Date() },
      
      { user: users[3]._id, activityName: "Running", occurrenceDate: new Date() },
      { user: users[3]._id, activityName: "Walking", occurrenceDate: new Date() },
      { user: users[3]._id, activityName: "Dancing", occurrenceDate: new Date() },
      
      { user: users[4]._id, activityName: "Walking", occurrenceDate: new Date() },
      { user: users[4]._id, activityName: "Running", occurrenceDate: new Date() },
      
      { user: users[5]._id, activityName: "Walking", occurrenceDate: new Date() },
      
      { user: users[6]._id, activityName: "Walking", occurrenceDate: new Date() },
      { user: users[7]._id, activityName: "Walking", occurrenceDate: new Date() },
      { user: users[8]._id, activityName: "Walking", occurrenceDate: new Date() },
      { user: users[9]._id, activityName: "Walking", occurrenceDate: new Date() },
    ]);

    console.log('Seeder data inserted successfully!');
  } catch (error) {
    console.error('Error inserting seeder data:', error);
  }
};

export default seeds();